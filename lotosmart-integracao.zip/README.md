# LotoSmart — protótipo integrado
## Requisitos
- Node.js 18+ (usa `fetch` nativo)
## Executar localmente
```bash
npm install
npm start
```
Abra http://localhost:3000 no navegador. Para iPhone, publique em HTTPS e abra no Safari; use Compartilhar > Adicionar à Tela de Início.
## Integração de resultados
O backend consulta o endpoint público usado pelo portal da CAIXA e mantém cache de 5 minutos. Esse endpoint não é uma API pública com SLA garantido e pode mudar, bloquear requisições ou alterar o esquema. Antes de produção, valide termos de uso, disponibilidade, limites e campos. Se necessário, substitua por fornecedor autorizado. Não há valores de resultados embutidos no protótipo.
## Segurança e produção
- Hospede o backend em HTTPS.
- Configure monitoramento, retentativas com limite e logs sem dados sensíveis.
- Para atualização periódica mesmo sem usuários acessando, adicione um job agendado/cron no servidor.
- Revise regras de acumulação para modalidades especiais e confirme dados contra o portal oficial.
- O navegador não deve consultar diretamente a fonte, evitando problemas de CORS e centralizando cache.
