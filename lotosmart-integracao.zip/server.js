const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

// Endpoint público usado pelo portal de loterias da CAIXA.
// Não é uma API pública com SLA garantido; valide os termos e disponibilidade
// antes de colocar em produção. Nunca exponha segredos no frontend.
const SLUGS = {
  "mega-sena": "megasena",
  "lotofacil": "lotofacil",
  "quina": "quina",
  "lotomania": "lotomania",
  "dupla-sena": "duplasena",
  "timemania": "timemania",
  "dia-de-sorte": "diadesorte",
  "mais-milionaria": "maismilionaria",
  "super-sete": "supersete",
  "federal": "federal",
  "loteca": "loteca"
};
const cache = new Map();
const TTL_MS = 5 * 60 * 1000;

app.use(express.static(path.join(__dirname, "public")));
app.get("/api/health", (_req, res) => res.json({ok:true, service:"LotoSmart", time:new Date().toISOString()}));

app.get("/api/loterias/:lottery", async (req, res) => {
  const key = req.params.lottery.toLowerCase();
  const slug = SLUGS[key];
  if (!slug) return res.status(400).json({error:"Modalidade não suportada."});
  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < TTL_MS) {
    return res.json({...cached.data, cached:true, fetchedAt:new Date(cached.at).toISOString()});
  }
  try {
    const url = `https://servicebus2.caixa.gov.br/portaldeloterias/api/${slug}`;
    const response = await fetch(url, {
      headers: {"Accept":"application/json, text/plain, */*", "User-Agent":"LotoSmart/1.0"},
      signal: AbortSignal.timeout(12000)
    });
    if (!response.ok) throw new Error(`Fonte respondeu HTTP ${response.status}`);
    const raw = await response.json();
    const data = normalize(raw, key);
    cache.set(key, {data, at:Date.now()});
    res.json({...data, cached:false, fetchedAt:new Date().toISOString()});
  } catch (err) {
    if (cached) return res.json({...cached.data, stale:true, fetchedAt:new Date(cached.at).toISOString(), warning:"Fonte indisponível; exibindo dados em cache."});
    res.status(502).json({error:"Não foi possível consultar os resultados agora.", detail:"A fonte pode estar indisponível ou ter alterado o formato. Tente novamente mais tarde."});
  }
});

function normalize(r, lottery) {
  const prizes = (r.listaRateioPremio || []).map(p => ({
    faixa: p.descricaoFaixa || null,
    ganhadores: Number(p.numeroDeGanhadores || 0),
    valorPremio: Number(p.valorPremio || 0)
  }));
  const principal = prizes[0] || null;
  const draws = (r.listaDezenas || []).map(String);
  const estimate = Number(r.valorEstimadoProximoConcurso || 0);
  const nextAccumulated = Number(r.valorAcumuladoProximoConcurso || 0);
  // Acumulação principal: inferida pelo número de ganhadores da faixa principal.
  // Modalidades especiais podem ter regras próprias; a fonte oficial é soberana.
  const accumulated = principal ? principal.ganhadores === 0 : null;
  return {
    modalidade: lottery,
    concurso: r.numero || null,
    dataApuracao: r.dataApuracao || null,
    dezenas: draws,
    acumulou: accumulated,
    premioEstimadoProximo: estimate,
    acumuladoProximo: nextAccumulated,
    arrecadacaoTotal: Number(r.valorArrecadado || 0),
    premiacoes: prizes,
    fonte: "Portal de Loterias CAIXA",
    sourceUrl: "https://loterias.caixa.gov.br/",
    observacao: r.observacao || null
  };
}

app.listen(PORT, () => console.log(`LotoSmart em http://localhost:${PORT}`));